<?php
// contact.php
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak Kami</title>
    <link rel="stylesheet" href="styles.css"> <!-- Gaya CSS -->
</head>
<body>

    <div class="container">
        <h1>Kontak Kami</h1>
        <p>Jika Anda memiliki pertanyaan atau ingin menghubungi kami, silakan gunakan informasi kontak berikut:</p>

        <h3>Email:</h3>
        <p><a href="mailto:fakhriafif788@gmail.com">fakhriafif788@gmail.com</a></p>

        <h3>Telepon:</h3>
        <p>+628997525289</p>

        <h3>Lokasi:</h3>
        <p>Jl.manggis, Perum Telaga Murni , Bekasi - Indonesia</p>
    </div>

</body>
</html>
